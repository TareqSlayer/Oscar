package com.iptv.app.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.iptv.app.R;
import com.iptv.app.ui.activity.ChannelsActivity;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Adapter for displaying categories
 */
public class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.ViewHolder> {
    private ArrayList<HashMap<String, Object>> categories;
    private Context context;

    public CategoriesAdapter(ArrayList<HashMap<String, Object>> categories, Context context) {
        this.categories = categories;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HashMap<String, Object> category = categories.get(position);
        
        String name = category.get("name") != null ? category.get("name").toString() : "Unknown";
        String id = category.get("id") != null ? category.get("id").toString().replace(".0", "") : "0";
        
        holder.categoryName.setText(name);
        
        holder.categoryContainer.setOnClickListener(v -> {
            Intent intent = new Intent(context, ChannelsActivity.class);
            intent.putExtra("category_id", id);
            intent.putExtra("category_name", name);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView categoryName;
        LinearLayout categoryContainer;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            categoryName = itemView.findViewById(R.id.category_name);
            categoryContainer = itemView.findViewById(R.id.category_container);
        }
    }
}
