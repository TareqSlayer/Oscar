package com.iptv.app.ui.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.iptv.app.R;
import com.iptv.app.network.NetworkUtil;
import com.iptv.app.ui.adapter.EventsAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import timber.log.Timber;

/**
 * Activity showing live events
 */
public class EventsActivity extends AppCompatActivity {
    private RecyclerView eventsRecyclerView;
    private ProgressBar progressBar;
    private TextView errorText;
    private TextView retryButton;
    private ArrayList<HashMap<String, Object>> events = new ArrayList<>();
    private EventsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);
        
        initializeViews();
        setupRecyclerView();
        loadEvents();
    }

    private void initializeViews() {
        ImageView backButton = findViewById(R.id.back_button);
        eventsRecyclerView = findViewById(R.id.events_rv);
        progressBar = findViewById(R.id.progress_bar);
        errorText = findViewById(R.id.error_text);
        retryButton = findViewById(R.id.retry_button);
        
        backButton.setOnClickListener(v -> finish());
        retryButton.setOnClickListener(v -> loadEvents());
    }

    private void setupRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        eventsRecyclerView.setLayoutManager(layoutManager);
        adapter = new EventsAdapter(events, this);
        eventsRecyclerView.setAdapter(adapter);
    }

    private void loadEvents() {
        showLoading();
        
        NetworkUtil.getEvents(new NetworkUtil.ApiCallback() {
            @Override
            public void onSuccess(ArrayList<HashMap<String, Object>> data) {
                runOnUiThread(() -> {
                    events.clear();
                    events.addAll(data);
                    adapter.notifyDataSetChanged();
                    hideLoading();
                    Timber.d("Events loaded: %d", data.size());
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    showError(error);
                    Timber.e("Error loading events: %s", error);
                });
            }
        });
    }

    private void showLoading() {
        progressBar.setVisibility(View.VISIBLE);
        errorText.setVisibility(View.GONE);
        retryButton.setVisibility(View.GONE);
        eventsRecyclerView.setVisibility(View.GONE);
    }

    private void hideLoading() {
        progressBar.setVisibility(View.GONE);
        eventsRecyclerView.setVisibility(View.VISIBLE);
    }

    private void showError(String message) {
        progressBar.setVisibility(View.GONE);
        eventsRecyclerView.setVisibility(View.GONE);
        errorText.setVisibility(View.VISIBLE);
        retryButton.setVisibility(View.VISIBLE);
        errorText.setText("خطأ: " + message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
