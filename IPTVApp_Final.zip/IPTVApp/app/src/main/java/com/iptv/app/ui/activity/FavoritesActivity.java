package com.iptv.app.ui.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.iptv.app.R;
import com.iptv.app.ui.adapter.CategoriesAdapter;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Activity showing favorite channels
 */
public class FavoritesActivity extends AppCompatActivity {
    private RecyclerView favoritesRecyclerView;
    private TextView emptyText;
    private ArrayList<HashMap<String, Object>> favorites = new ArrayList<>();
    private CategoriesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
        
        initializeViews();
        setupRecyclerView();
        loadFavorites();
    }

    private void initializeViews() {
        ImageView backButton = findViewById(R.id.back_button);
        favoritesRecyclerView = findViewById(R.id.favorites_rv);
        emptyText = findViewById(R.id.empty_text);
        
        backButton.setOnClickListener(v -> finish());
    }

    private void setupRecyclerView() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        favoritesRecyclerView.setLayoutManager(gridLayoutManager);
        adapter = new CategoriesAdapter(favorites, this);
        favoritesRecyclerView.setAdapter(adapter);
    }

    private void loadFavorites() {
        // TODO: Load favorites from SharedPreferences or database
        if (favorites.isEmpty()) {
            emptyText.setVisibility(View.VISIBLE);
            favoritesRecyclerView.setVisibility(View.GONE);
        } else {
            emptyText.setVisibility(View.GONE);
            favoritesRecyclerView.setVisibility(View.VISIBLE);
        }
    }
}
