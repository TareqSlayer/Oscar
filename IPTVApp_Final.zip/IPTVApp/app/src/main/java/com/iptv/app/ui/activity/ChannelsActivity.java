package com.iptv.app.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.iptv.app.R;
import com.iptv.app.network.NetworkUtil;
import com.iptv.app.ui.adapter.ChannelsAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import timber.log.Timber;

/**
 * Activity showing channels for a selected category
 */
public class ChannelsActivity extends AppCompatActivity {
    private String categoryId;
    private String categoryName;
    private RecyclerView channelsRecyclerView;
    private ProgressBar progressBar;
    private TextView errorText;
    private TextView retryButton;
    private ArrayList<HashMap<String, Object>> channels = new ArrayList<>();
    private ChannelsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_channels);
        
        getIntentData();
        initializeViews();
        setupRecyclerView();
        loadChannels();
    }

    private void getIntentData() {
        Intent intent = getIntent();
        categoryId = intent.getStringExtra("category_id");
        categoryName = intent.getStringExtra("category_name");
    }

    private void initializeViews() {
        ImageView backButton = findViewById(R.id.back_button);
        TextView titleText = findViewById(R.id.title_text);
        channelsRecyclerView = findViewById(R.id.channels_rv);
        progressBar = findViewById(R.id.progress_bar);
        errorText = findViewById(R.id.error_text);
        retryButton = findViewById(R.id.retry_button);
        
        titleText.setText(categoryName);
        backButton.setOnClickListener(v -> finish());
        retryButton.setOnClickListener(v -> loadChannels());
    }

    private void setupRecyclerView() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        channelsRecyclerView.setLayoutManager(gridLayoutManager);
        adapter = new ChannelsAdapter(channels, this);
        channelsRecyclerView.setAdapter(adapter);
    }

    private void loadChannels() {
        showLoading();
        
        NetworkUtil.getChannels(categoryId, new NetworkUtil.ApiCallback() {
            @Override
            public void onSuccess(ArrayList<HashMap<String, Object>> data) {
                runOnUiThread(() -> {
                    channels.clear();
                    channels.addAll(data);
                    adapter.notifyDataSetChanged();
                    hideLoading();
                    Timber.d("Channels loaded: %d", data.size());
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    showError(error);
                    Timber.e("Error loading channels: %s", error);
                });
            }
        });
    }

    private void showLoading() {
        progressBar.setVisibility(View.VISIBLE);
        errorText.setVisibility(View.GONE);
        retryButton.setVisibility(View.GONE);
        channelsRecyclerView.setVisibility(View.GONE);
    }

    private void hideLoading() {
        progressBar.setVisibility(View.GONE);
        channelsRecyclerView.setVisibility(View.VISIBLE);
    }

    private void showError(String message) {
        progressBar.setVisibility(View.GONE);
        channelsRecyclerView.setVisibility(View.GONE);
        errorText.setVisibility(View.VISIBLE);
        retryButton.setVisibility(View.VISIBLE);
        errorText.setText("خطأ: " + message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
