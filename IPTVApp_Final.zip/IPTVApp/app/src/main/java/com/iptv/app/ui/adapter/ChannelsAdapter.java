package com.iptv.app.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.iptv.app.R;
import com.iptv.app.ui.activity.PlayerActivity;
import java.util.ArrayList;
import java.util.HashMap;
import timber.log.Timber;

/**
 * Adapter for displaying channels
 */
public class ChannelsAdapter extends RecyclerView.Adapter<ChannelsAdapter.ViewHolder> {
    private ArrayList<HashMap<String, Object>> channels;
    private Context context;

    public ChannelsAdapter(ArrayList<HashMap<String, Object>> channels, Context context) {
        this.channels = channels;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_channel, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HashMap<String, Object> channel = channels.get(position);
        
        String name = channel.get("name") != null ? channel.get("name").toString() : "Unknown";
        String logo = channel.get("logo") != null ? channel.get("logo").toString() : "";
        String id = channel.get("id") != null ? channel.get("id").toString().replace(".0", "") : "0";
        
        holder.channelName.setText(name);
        
        // Load logo using Glide
        if (!logo.isEmpty()) {
            Glide.with(context)
                    .load(logo)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .into(holder.channelLogo);
        } else {
            holder.channelLogo.setImageResource(R.drawable.ic_placeholder);
        }
        
        holder.channelContainer.setOnClickListener(v -> {
            Timber.d("Channel clicked: %s", name);
            // Fetch channel details and start playback
            fetchChannelDetailAndPlay(id, name);
        });
    }

    @Override
    public int getItemCount() {
        return channels.size();
    }

    private void fetchChannelDetailAndPlay(String channelId, String channelName) {
        // This would be called to get the streaming URL
        // For now, we'll navigate to player with the channel ID
        Intent intent = new Intent(context, PlayerActivity.class);
        intent.putExtra("channel_id", channelId);
        intent.putExtra("channel_name", channelName);
        context.startActivity(intent);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView channelLogo;
        TextView channelName;
        LinearLayout channelContainer;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            channelLogo = itemView.findViewById(R.id.channel_logo);
            channelName = itemView.findViewById(R.id.channel_name);
            channelContainer = itemView.findViewById(R.id.channel_container);
        }
    }
}
