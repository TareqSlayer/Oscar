package com.iptv.app.network;

import android.util.Base64;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import timber.log.Timber;

/**
 * Utility class for handling network requests and data decryption
 */
public class NetworkUtil {
    private static final String BASE_URL = "https://a2.apk-api.com/api";
    private static final String ENCRYPTION_KEY = "c!xZj+N9&G@Ev@vw";
    private static final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .build();
    private static final Gson gson = new Gson();

    public interface ApiCallback {
        void onSuccess(ArrayList<HashMap<String, Object>> data);
        void onError(String error);
    }

    /**
     * Fetch categories from API
     */
    public static void getCategories(ApiCallback callback) {
        fetchAndDecrypt(BASE_URL + "/categories", callback);
    }

    /**
     * Fetch channels for a specific category
     */
    public static void getChannels(String categoryId, ApiCallback callback) {
        fetchAndDecrypt(BASE_URL + "/categories/" + categoryId + "/channels", callback);
    }

    /**
     * Fetch events from API
     */
    public static void getEvents(ApiCallback callback) {
        fetchAndDecrypt(BASE_URL + "/events", callback);
    }

    /**
     * Fetch channel details
     */
    public static void getChannelDetail(String channelId, final ApiCallback callback) {
        new Thread(() -> {
            try {
                Request request = new Request.Builder()
                        .url(BASE_URL + "/channel/" + channelId)
                        .addHeader("Accept", "application/json")
                        .addHeader("User-Agent", "okhttp/4.12.0")
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();
                    String timestamp = response.header("t", "");
                    
                    ArrayList<HashMap<String, Object>> decrypted = decryptResponse(responseBody, timestamp);
                    if (decrypted != null && !decrypted.isEmpty()) {
                        callback.onSuccess(decrypted);
                    } else {
                        callback.onError("فشل فك التشفير");
                    }
                } else {
                    callback.onError("خطأ في الاتصال: " + response.code());
                }
                response.close();
            } catch (Exception e) {
                Timber.e(e, "Error fetching channel detail");
                callback.onError(e.getMessage());
            }
        }).start();
    }

    /**
     * Fetch event details
     */
    public static void getEventDetail(String eventId, final ApiCallback callback) {
        new Thread(() -> {
            try {
                Request request = new Request.Builder()
                        .url(BASE_URL + "/event/" + eventId)
                        .addHeader("Accept", "application/json")
                        .addHeader("User-Agent", "okhttp/4.12.0")
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();
                    String timestamp = response.header("t", "");
                    
                    ArrayList<HashMap<String, Object>> decrypted = decryptResponse(responseBody, timestamp);
                    if (decrypted != null && !decrypted.isEmpty()) {
                        callback.onSuccess(decrypted);
                    } else {
                        callback.onError("فشل فك التشفير");
                    }
                } else {
                    callback.onError("خطأ في الاتصال: " + response.code());
                }
                response.close();
            } catch (Exception e) {
                Timber.e(e, "Error fetching event detail");
                callback.onError(e.getMessage());
            }
        }).start();
    }

    /**
     * Generic fetch and decrypt method
     */
    private static void fetchAndDecrypt(String url, ApiCallback callback) {
        new Thread(() -> {
            try {
                Request request = new Request.Builder()
                        .url(url)
                        .addHeader("Accept", "application/json")
                        .addHeader("User-Agent", "okhttp/4.12.0")
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();
                    String timestamp = response.header("t", "");
                    
                    ArrayList<HashMap<String, Object>> decrypted = decryptResponse(responseBody, timestamp);
                    if (decrypted != null) {
                        callback.onSuccess(decrypted);
                    } else {
                        callback.onError("فشل فك التشفير");
                    }
                } else {
                    callback.onError("خطأ في الاتصال: " + response.code());
                }
                response.close();
            } catch (Exception e) {
                Timber.e(e, "Error fetching data");
                callback.onError(e.getMessage());
            }
        }).start();
    }

    /**
     * Decrypt response using XOR cipher
     */
    private static ArrayList<HashMap<String, Object>> decryptResponse(String encryptedText, String timestamp) {
        try {
            String key = ENCRYPTION_KEY + timestamp;
            byte[] decodedBytes = Base64.decode(encryptedText, Base64.DEFAULT);
            byte[] resultBytes = new byte[decodedBytes.length];
            int keyLength = key.length();
            
            for (int i = 0; i < decodedBytes.length; i++) {
                resultBytes[i] = (byte) (decodedBytes[i] ^ key.charAt(i % keyLength));
            }
            
            String decryptedJson = new String(resultBytes, "UTF-8").replace("\\/", "/");
            HashMap<String, Object> map = gson.fromJson(decryptedJson, new TypeToken<HashMap<String, Object>>(){}.getType());
            
            if (map != null && map.containsKey("data")) {
                Object dataObj = map.get("data");
                if (dataObj instanceof ArrayList) {
                    return (ArrayList<HashMap<String, Object>>) dataObj;
                } else {
                    ArrayList<HashMap<String, Object>> list = new ArrayList<>();
                    list.add((HashMap<String, Object>) dataObj);
                    return list;
                }
            }
            return null;
        } catch (Exception e) {
            Timber.e(e, "Error decrypting response");
            return null;
        }
    }
}
