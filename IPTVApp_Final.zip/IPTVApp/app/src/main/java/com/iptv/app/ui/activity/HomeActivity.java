package com.iptv.app.ui.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.iptv.app.R;
import com.iptv.app.network.NetworkUtil;
import com.iptv.app.ui.adapter.CategoriesAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import timber.log.Timber;

/**
 * Home screen showing categories
 */
public class HomeActivity extends AppCompatActivity {
    private RecyclerView categoriesRecyclerView;
    private ProgressBar progressBar;
    private TextView errorText;
    private TextView retryButton;
    private ArrayList<HashMap<String, Object>> categories = new ArrayList<>();
    private CategoriesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        
        initializeViews();
        setupRecyclerView();
        loadCategories();
    }

    private void initializeViews() {
        categoriesRecyclerView = findViewById(R.id.categories_rv);
        progressBar = findViewById(R.id.progress_bar);
        errorText = findViewById(R.id.error_text);
        retryButton = findViewById(R.id.retry_button);
        
        retryButton.setOnClickListener(v -> loadCategories());
    }

    private void setupRecyclerView() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        categoriesRecyclerView.setLayoutManager(gridLayoutManager);
        adapter = new CategoriesAdapter(categories, this);
        categoriesRecyclerView.setAdapter(adapter);
    }

    private void loadCategories() {
        showLoading();
        
        NetworkUtil.getCategories(new NetworkUtil.ApiCallback() {
            @Override
            public void onSuccess(ArrayList<HashMap<String, Object>> data) {
                runOnUiThread(() -> {
                    categories.clear();
                    categories.addAll(data);
                    adapter.notifyDataSetChanged();
                    hideLoading();
                    Timber.d("Categories loaded: %d", data.size());
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    showError(error);
                    Timber.e("Error loading categories: %s", error);
                });
            }
        });
    }

    private void showLoading() {
        progressBar.setVisibility(View.VISIBLE);
        errorText.setVisibility(View.GONE);
        retryButton.setVisibility(View.GONE);
        categoriesRecyclerView.setVisibility(View.GONE);
    }

    private void hideLoading() {
        progressBar.setVisibility(View.GONE);
        categoriesRecyclerView.setVisibility(View.VISIBLE);
    }

    private void showError(String message) {
        progressBar.setVisibility(View.GONE);
        categoriesRecyclerView.setVisibility(View.GONE);
        errorText.setVisibility(View.VISIBLE);
        retryButton.setVisibility(View.VISIBLE);
        errorText.setText("خطأ: " + message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
