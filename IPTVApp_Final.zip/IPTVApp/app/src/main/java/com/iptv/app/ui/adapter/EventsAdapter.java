package com.iptv.app.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.iptv.app.R;
import com.iptv.app.ui.activity.PlayerActivity;
import java.util.ArrayList;
import java.util.HashMap;
import timber.log.Timber;

/**
 * Adapter for displaying events
 */
public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.ViewHolder> {
    private ArrayList<HashMap<String, Object>> events;
    private Context context;

    public EventsAdapter(ArrayList<HashMap<String, Object>> events, Context context) {
        this.events = events;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_event, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HashMap<String, Object> event = events.get(position);
        
        String title = event.get("title") != null ? event.get("title").toString() : "Unknown";
        String description = event.get("description") != null ? event.get("description").toString() : "";
        String image = event.get("image") != null ? event.get("image").toString() : "";
        String id = event.get("id") != null ? event.get("id").toString().replace(".0", "") : "0";
        
        holder.eventTitle.setText(title);
        holder.eventDescription.setText(description);
        
        // Load image using Glide
        if (!image.isEmpty()) {
            Glide.with(context)
                    .load(image)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .into(holder.eventImage);
        } else {
            holder.eventImage.setImageResource(R.drawable.ic_placeholder);
        }
        
        holder.eventContainer.setOnClickListener(v -> {
            Timber.d("Event clicked: %s", title);
            // Navigate to player with event ID
            Intent intent = new Intent(context, PlayerActivity.class);
            intent.putExtra("event_id", id);
            intent.putExtra("event_name", title);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView eventImage;
        TextView eventTitle;
        TextView eventDescription;
        LinearLayout eventContainer;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            eventImage = itemView.findViewById(R.id.event_image);
            eventTitle = itemView.findViewById(R.id.event_title);
            eventDescription = itemView.findViewById(R.id.event_description);
            eventContainer = itemView.findViewById(R.id.event_container);
        }
    }
}
