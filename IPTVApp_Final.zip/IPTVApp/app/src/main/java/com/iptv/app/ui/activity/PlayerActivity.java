package com.iptv.app.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import com.iptv.app.R;
import com.iptv.app.network.NetworkUtil;
import java.util.ArrayList;
import java.util.HashMap;
import timber.log.Timber;

/**
 * Professional video player activity with ExoPlayer
 */
public class PlayerActivity extends AppCompatActivity {
    private PlayerView playerView;
    private ExoPlayer exoPlayer;
    private ProgressBar loadingIndicator;
    private TextView errorText;
    private String channelId;
    private String channelName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        
        getIntentData();
        initializeViews();
        loadChannelAndPlay();
    }

    private void getIntentData() {
        Intent intent = getIntent();
        channelId = intent.getStringExtra("channel_id");
        channelName = intent.getStringExtra("channel_name");
    }

    private void initializeViews() {
        playerView = findViewById(R.id.player_view);
        loadingIndicator = findViewById(R.id.loading_indicator);
        errorText = findViewById(R.id.error_text);
        
        // Initialize ExoPlayer
        exoPlayer = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(exoPlayer);
        
        // Configure player
        playerView.setShowSubtitleButton(true);
        playerView.setShowNextButton(false);
        playerView.setShowPreviousButton(false);
    }

    private void loadChannelAndPlay() {
        showLoading();
        
        NetworkUtil.getChannelDetail(channelId, new NetworkUtil.ApiCallback() {
            @Override
            public void onSuccess(ArrayList<HashMap<String, Object>> data) {
                runOnUiThread(() -> {
                    if (!data.isEmpty()) {
                        HashMap<String, Object> channelData = data.get(0);
                        String url = channelData.get("url") != null ? 
                                channelData.get("url").toString() : "";
                        String userAgent = channelData.get("user_agent") != null ? 
                                channelData.get("user_agent").toString() : "";
                        
                        if (!url.isEmpty()) {
                            playStream(url, userAgent);
                        } else {
                            showError("لم يتم العثور على رابط البث");
                        }
                    } else {
                        showError("لم يتم العثور على بيانات القناة");
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    showError("خطأ: " + error);
                    Timber.e("Error loading channel: %s", error);
                });
            }
        });
    }

    private void playStream(String url, String userAgent) {
        try {
            Timber.d("Playing stream: %s", url);
            
            // Detect media type
            String mimeType = detectMimeType(url);
            
            // Create media item
            MediaItem mediaItem = new MediaItem.Builder()
                    .setUri(url)
                    .setMimeType(mimeType)
                    .build();
            
            // Set media item and prepare
            exoPlayer.setMediaItem(mediaItem);
            exoPlayer.prepare();
            exoPlayer.play();
            
            hideLoading();
        } catch (Exception e) {
            Timber.e(e, "Error playing stream");
            showError("خطأ في تشغيل البث");
        }
    }

    private String detectMimeType(String url) {
        if (url.contains(".m3u8")) {
            return MimeTypes.APPLICATION_M3U8;
        } else if (url.contains(".mpd")) {
            return MimeTypes.APPLICATION_MPD;
        } else if (url.contains(".mp4")) {
            return MimeTypes.VIDEO_MP4;
        }
        return MimeTypes.APPLICATION_M3U8; // Default to HLS
    }

    private void showLoading() {
        loadingIndicator.setVisibility(View.VISIBLE);
        errorText.setVisibility(View.GONE);
    }

    private void hideLoading() {
        loadingIndicator.setVisibility(View.GONE);
        errorText.setVisibility(View.GONE);
    }

    private void showError(String message) {
        loadingIndicator.setVisibility(View.GONE);
        errorText.setVisibility(View.VISIBLE);
        errorText.setText(message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (exoPlayer != null) {
            exoPlayer.play();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (exoPlayer != null) {
            exoPlayer.pause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (exoPlayer != null) {
            exoPlayer.release();
            exoPlayer = null;
        }
    }
}
